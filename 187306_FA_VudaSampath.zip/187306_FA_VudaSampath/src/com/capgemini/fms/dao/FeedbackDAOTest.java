package com.capgemini.fms.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.capgemini.fms.bean.Feedback;


class FeedbackDAOTest {

	@Test
	void test() {
		Feedback fbObj = new Feedback();
		Map<String, Integer> MathFeedbackMap=new HashMap<String, Integer>();
		MathFeedbackMap.put( "abc" ,4);
	}

}
