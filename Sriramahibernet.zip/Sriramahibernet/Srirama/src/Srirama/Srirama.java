package Srirama;

public class Srirama {
	public static void main(String[] args) {
		System.out.println("jai srirama");
	}
	// TODO Auto-generated constructor stub

}
