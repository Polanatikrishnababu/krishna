package com.pdw.entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="mgr_store")
public class Manager extends Employee {
	
	 
	@Column(length=10)
	private String departmentName;
	public String getDepartmentName() {
	return departmentName;
	}
	public void setDepartmentName(String departmentName) {
	this.departmentName = departmentName;
	}
	}


